import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Search, Filter, TrendingUp, TrendingDown, Star, BarChart3, Zap } from 'lucide-react';

const screenerData = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', sector: 'Energy', pe: 22.4, roe: 13.5, score: 8.2, rec: 'BUY' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', sector: 'IT', pe: 28.1, roe: 45.2, score: 9.1, rec: 'STRONG BUY' },
  { symbol: 'INFY', name: 'Infosys Ltd', sector: 'IT', pe: 24.5, roe: 31.8, score: 8.7, rec: 'BUY' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank Ltd', sector: 'Banking', pe: 18.9, roe: 16.4, score: 8.4, rec: 'BUY' },
  { symbol: 'ICICIBANK', name: 'ICICI Bank Ltd', sector: 'Banking', pe: 17.2, roe: 17.1, score: 8.0, rec: 'BUY' },
  { symbol: 'ASIANPAINT', name: 'Asian Paints Ltd', sector: 'Paints', pe: 52.1, roe: 29.6, score: 7.5, rec: 'HOLD' },
  { symbol: 'WIPRO', name: 'Wipro Ltd', sector: 'IT', pe: 20.3, roe: 17.9, score: 7.2, rec: 'HOLD' },
  { symbol: 'MARUTI', name: 'Maruti Suzuki India', sector: 'Auto', pe: 26.8, roe: 16.0, score: 7.9, rec: 'BUY' },
];

const sectors = ['All', 'IT', 'Banking', 'Energy', 'Auto', 'Paints'];

const recColors = {
  'STRONG BUY': 'badge-green',
  'BUY': 'badge-blue',
  'HOLD': 'badge-gold',
  'SELL': 'badge-red',
};

export default function Research() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState('All');
  const [minScore, setMinScore] = useState('');
  const [watchlist, setWatchlist] = useState([]);

  const filtered = screenerData.filter((s) => {
    const matchSearch = s.symbol.includes(searchTerm.toUpperCase()) || s.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchSector = selectedSector === 'All' || s.sector === selectedSector;
    const matchScore = !minScore || s.score >= parseFloat(minScore);
    return matchSearch && matchSector && matchScore;
  });

  const toggleWatchlist = (symbol) => {
    setWatchlist((prev) =>
      prev.includes(symbol) ? prev.filter((s) => s !== symbol) : [...prev, symbol]
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="page-wrapper"
    >
      <div className="page-title-row">
        <div className="page-icon-wrap research-icon">
          <BookOpen size={28} />
        </div>
        <div>
          <h1 className="page-title">Deep Research Desk</h1>
          <p className="text-muted">Screen, filter, and discover investment opportunities</p>
        </div>
      </div>

      {/* Filters Row */}
      <div className="glass-card filter-bar">
        <div className="field-group filter-field">
          <label className="field-label"><Search size={14} /> Search Stock</label>
          <input
            className="form-input"
            placeholder="Symbol or company name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="field-group filter-field">
          <label className="field-label"><Filter size={14} /> Sector</label>
          <div className="sector-pill-row">
            {sectors.map((s) => (
              <button
                key={s}
                className={`sector-filter-btn ${selectedSector === s ? 'active' : ''}`}
                onClick={() => setSelectedSector(s)}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="field-group filter-field" style={{ minWidth: '180px' }}>
          <label className="field-label"><Zap size={14} /> Min Health Score</label>
          <input
            type="number"
            className="form-input"
            placeholder="e.g. 7.5"
            min="0" max="10" step="0.1"
            value={minScore}
            onChange={(e) => setMinScore(e.target.value)}
          />
        </div>
      </div>

      {/* Screener Table */}
      <div className="glass-card" style={{ padding: '1.5rem', overflow: 'auto' }}>
        <h3 className="section-label"><BarChart3 size={18} /> Stock Screener ({filtered.length} results)</h3>
        <table className="holdings-table">
          <thead>
            <tr>
              <th>Symbol</th>
              <th>Company</th>
              <th>Sector</th>
              <th>P/E Ratio</th>
              <th>ROE %</th>
              <th>Health Score</th>
              <th>Recommendation</th>
              <th>Watchlist</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((s, i) => (
              <tr key={i}>
                <td><span className="ticker-capsule" style={{ fontSize: '0.75rem' }}>{s.symbol}</span></td>
                <td className="text-muted" style={{ fontSize: '0.85rem' }}>{s.name}</td>
                <td><span className="sector-capsule">{s.sector}</span></td>
                <td>{s.pe}x</td>
                <td className="text-green fw-700">{s.roe}%</td>
                <td>
                  <div className="score-bar-wrap">
                    <div className="score-bar" style={{ width: `${s.score * 10}%` }}></div>
                    <span className="score-num">{s.score}</span>
                  </div>
                </td>
                <td><span className={recColors[s.rec] || 'badge-blue'}>{s.rec}</span></td>
                <td>
                  <button
                    className={`watchlist-btn ${watchlist.includes(s.symbol) ? 'starred' : ''}`}
                    onClick={() => toggleWatchlist(s.symbol)}
                    title={watchlist.includes(s.symbol) ? 'Remove from Watchlist' : 'Add to Watchlist'}
                  >
                    <Star size={16} fill={watchlist.includes(s.symbol) ? 'currentColor' : 'none'} />
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={8} className="text-muted" style={{ textAlign: 'center', padding: '2rem' }}>No stocks match your filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Watchlist */}
      {watchlist.length > 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="glass-card watchlist-panel">
          <h3 className="section-label"><Star size={18} /> My Watchlist</h3>
          <div className="watchlist-chips">
            {watchlist.map((s) => (
              <span key={s} className="ticker-capsule watchlist-chip">
                {s}
                <button onClick={() => toggleWatchlist(s)} className="chip-remove">×</button>
              </span>
            ))}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
