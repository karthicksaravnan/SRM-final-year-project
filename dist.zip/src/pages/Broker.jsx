import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Briefcase, Link2, Shield, CheckCircle, AlertCircle, KeyRound, Smartphone, Lock, LogOut } from 'lucide-react';
import * as api from '../lib/api';

export default function Broker({ user }) {
  const [step, setStep] = useState(1); // 1 = credentials+TOTP, 2 = MPIN
  const [accessToken, setAccessToken] = useState('');
  const [mobile, setMobile] = useState('');
  const [ucc, setUcc] = useState('');
  const [totp, setTotp] = useState('');
  const [mpin, setMpin] = useState('');

  const [viewSession, setViewSession] = useState(null); // {sid, view_token}
  const [status, setStatus] = useState(null); // backend broker status
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const refreshStatus = async () => {
    if (!user) return;
    try {
      const s = await api.brokerStatus(user.id);
      setStatus(s);
    } catch {
      setStatus({ connected: false });
    }
  };

  useEffect(() => {
    refreshStatus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const handleStep1 = async () => {
    setError('');
    if (!accessToken || !mobile || !ucc || !totp) {
      return setError('Access token, mobile number, UCC and TOTP are all required.');
    }
    setLoading(true);
    try {
      const res = await api.brokerLogin({
        access_token: accessToken,
        mobile_number: mobile,
        ucc,
        totp,
      });
      setViewSession({ sid: res.sid, view_token: res.view_token });
      setStep(2);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStep2 = async () => {
    setError('');
    if (!mpin) return setError('MPIN is required.');
    setLoading(true);
    try {
      await api.brokerValidate({
        user_id: user.id,
        access_token: accessToken,
        sid: viewSession.sid,
        view_token: viewSession.view_token,
        mpin,
      });
      setStep(1);
      setViewSession(null);
      setTotp('');
      setMpin('');
      await refreshStatus();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDisconnect = async () => {
    setLoading(true);
    try {
      await api.brokerDisconnect(user.id);
      await refreshStatus();
    } finally {
      setLoading(false);
    }
  };

  const connected = status?.connected;

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="page-wrapper">
      <div className="page-title-row">
        <div className="page-icon-wrap broker-icon"><Briefcase size={28} /></div>
        <div>
          <h1 className="page-title">Broker Connect</h1>
          <p className="text-muted">Link your Kotak Securities Neo account for live trading data</p>
        </div>
      </div>

      <div className="two-col-grid">
        {/* Connection Form */}
        <div className="glass-card broker-form-card">
          {/* Stepper */}
          <div className="kotak-stepper">
            <div className={`kstep ${step >= 1 ? 'active' : ''}`}>
              <span className="kstep-num">1</span> Credentials + TOTP
            </div>
            <div className="kstep-divider" />
            <div className={`kstep ${step >= 2 ? 'active' : ''}`}>
              <span className="kstep-num">2</span> MPIN
            </div>
          </div>

          {connected ? (
            <div className="success-banner" style={{ marginBottom: '1rem' }}>
              <CheckCircle size={18} /> Already connected as {status.greeting_name || status.ucc || 'Kotak user'}.
            </div>
          ) : null}

          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div key="s1" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
                <h3 className="section-label"><KeyRound size={18} /> Kotak Neo Login</h3>

                <div className="field-group">
                  <label className="field-label">API Access Token</label>
                  <input type="password" className="form-input" placeholder="Token from NEO API dashboard"
                    value={accessToken} onChange={(e) => setAccessToken(e.target.value)} />
                </div>
                <div className="two-col-fields">
                  <div className="field-group">
                    <label className="field-label">Mobile Number</label>
                    <input className="form-input" placeholder="+91XXXXXXXXXX" value={mobile}
                      onChange={(e) => setMobile(e.target.value)} />
                  </div>
                  <div className="field-group">
                    <label className="field-label">Client Code (UCC)</label>
                    <input className="form-input" placeholder="e.g. ABCDE" value={ucc}
                      onChange={(e) => setUcc(e.target.value.toUpperCase())} />
                  </div>
                </div>
                <div className="field-group">
                  <label className="field-label">TOTP (6-digit)</label>
                  <input className="form-input" placeholder="From authenticator app" maxLength={6} value={totp}
                    onChange={(e) => setTotp(e.target.value.replace(/\D/g, ''))} />
                </div>

                {error && <div className="error-banner"><AlertCircle size={16} /> {error}</div>}

                <button className="search-btn connect-btn" onClick={handleStep1} disabled={loading}>
                  <Smartphone size={16} /> {loading ? 'Verifying...' : 'Verify & Continue'}
                </button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div key="s2" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                <h3 className="section-label"><Lock size={18} /> Enter MPIN</h3>
                <p className="text-muted" style={{ marginBottom: '1rem' }}>
                  TOTP verified. Enter your 6-digit MPIN to generate the trading session.
                </p>
                <div className="field-group">
                  <label className="field-label">MPIN</label>
                  <input type="password" className="form-input" placeholder="6-digit MPIN" maxLength={6} value={mpin}
                    onChange={(e) => setMpin(e.target.value.replace(/\D/g, ''))}
                    onKeyDown={(e) => e.key === 'Enter' && handleStep2()} />
                </div>

                {error && <div className="error-banner"><AlertCircle size={16} /> {error}</div>}

                <div style={{ display: 'flex', gap: '0.75rem' }}>
                  <button className="outline-btn" onClick={() => { setStep(1); setError(''); }} disabled={loading}>Back</button>
                  <button className="search-btn connect-btn" style={{ marginTop: 0, flex: 1 }} onClick={handleStep2} disabled={loading}>
                    <Link2 size={16} /> {loading ? 'Connecting...' : 'Complete Login'}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Status Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-card">
            <h3 className="section-label"><Shield size={18} /> Connection Status</h3>
            <div className="status-row">
              <span className="text-muted">Broker</span>
              <span className={connected ? 'text-green fw-700' : 'text-muted'}>
                {connected ? (status.broker || 'Kotak Neo') : 'Not Connected'}
              </span>
            </div>
            <div className="status-row">
              <span className="text-muted">Account</span>
              <span className={connected ? 'fw-700' : 'text-muted'}>
                {connected ? (status.greeting_name || status.ucc || '—') : 'N/A'}
              </span>
            </div>
            <div className="status-row">
              <span className="text-muted">Session Status</span>
              <span className={connected ? 'badge-green' : 'badge-red'}>{connected ? 'Active' : 'Inactive'}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Trading Data Access</span>
              <span className={connected ? 'badge-green' : 'badge-red'}>{connected ? 'Enabled' : 'Disabled'}</span>
            </div>

            {connected && (
              <button className="outline-btn" style={{ marginTop: '1rem', width: '100%' }} onClick={handleDisconnect} disabled={loading}>
                <LogOut size={14} /> Disconnect
              </button>
            )}
          </div>

          <div className="glass-card info-box">
            <AlertCircle size={18} className="text-gold" />
            <p className="text-muted" style={{ fontSize: '0.9rem', marginTop: '0.75rem' }}>
              Kotak Neo uses TOTP login. Register TOTP once in the NEO app (Invest → Trade API), then log in here with your access token, mobile, UCC, TOTP and MPIN. Your session token is stored server-side and used for Orders, Trades and Holdings.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
