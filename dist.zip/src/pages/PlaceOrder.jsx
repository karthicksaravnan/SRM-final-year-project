import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, TrendingUp, TrendingDown, CheckCircle, AlertCircle, ChevronDown } from 'lucide-react';

const orderTypes = ['Market', 'Limit', 'Stop Loss', 'Stop Loss Market'];
const productTypes = ['Intraday (MIS)', 'Delivery (CNC)', 'Normal (NRML)'];
const exchanges = ['NSE', 'BSE'];

export default function PlaceOrder() {
  const [symbol, setSymbol] = useState('');
  const [orderSide, setOrderSide] = useState('BUY');
  const [orderType, setOrderType] = useState('Market');
  const [product, setProduct] = useState('Delivery (CNC)');
  const [exchange, setExchange] = useState('NSE');
  const [qty, setQty] = useState('');
  const [price, setPrice] = useState('');
  const [triggerPrice, setTriggerPrice] = useState('');
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderError, setOrderError] = useState('');

  const isLimitOrder = orderType === 'Limit' || orderType === 'Stop Loss';
  const isSLOrder = orderType === 'Stop Loss' || orderType === 'Stop Loss Market';

  const handlePlaceOrder = () => {
    setOrderError('');
    if (!symbol || !qty) {
      setOrderError('Symbol and Quantity are required.');
      return;
    }
    if (isLimitOrder && !price) {
      setOrderError('Price is required for limit orders.');
      return;
    }
    setOrderPlaced(true);
    setTimeout(() => setOrderPlaced(false), 4000);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="page-wrapper"
    >
      <div className="page-title-row">
        <div className="page-icon-wrap order-icon">
          <ShoppingCart size={28} />
        </div>
        <div>
          <h1 className="page-title">Place Order</h1>
          <p className="text-muted">Execute trades directly from your connected broker</p>
        </div>
      </div>

     

      <div className="two-col-grid">
        {/* Order Form */}
        <div className="glass-card order-form-card">
          {/* Buy / Sell Toggle */}
          <div className="order-side-toggle">
            <button
              className={`side-btn ${orderSide === 'BUY' ? 'active-buy' : ''}`}
              onClick={() => setOrderSide('BUY')}
            >
              <TrendingUp size={16} /> BUY
            </button>
            <button
              className={`side-btn ${orderSide === 'SELL' ? 'active-sell' : ''}`}
              onClick={() => setOrderSide('SELL')}
            >
              <TrendingDown size={16} /> SELL
            </button>
          </div>

          <div className="field-group">
            <label className="field-label">Stock Symbol</label>
            <input
              className="form-input"
              placeholder="e.g. RELIANCE, TCS, INFY"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
            />
          </div>

          <div className="two-col-fields">
            <div className="field-group">
              <label className="field-label">Exchange</label>
              <div className="select-wrapper">
                <select className="form-select" value={exchange} onChange={(e) => setExchange(e.target.value)}>
                  {exchanges.map((e) => <option key={e}>{e}</option>)}
                </select>
                <ChevronDown size={16} className="select-icon" />
              </div>
            </div>

            <div className="field-group">
              <label className="field-label">Order Type</label>
              <div className="select-wrapper">
                <select className="form-select" value={orderType} onChange={(e) => setOrderType(e.target.value)}>
                  {orderTypes.map((t) => <option key={t}>{t}</option>)}
                </select>
                <ChevronDown size={16} className="select-icon" />
              </div>
            </div>
          </div>

          <div className="field-group">
            <label className="field-label">Product Type</label>
            <div className="select-wrapper">
              <select className="form-select" value={product} onChange={(e) => setProduct(e.target.value)}>
                {productTypes.map((p) => <option key={p}>{p}</option>)}
              </select>
              <ChevronDown size={16} className="select-icon" />
            </div>
          </div>

          <div className="two-col-fields">
            <div className="field-group">
              <label className="field-label">Quantity</label>
              <input
                type="number"
                className="form-input"
                placeholder="No. of shares"
                value={qty}
                onChange={(e) => setQty(e.target.value)}
                min="1"
              />
            </div>
            <div className="field-group">
              <label className="field-label">Price (₹) {orderType === 'Market' ? <span className="field-note">— Market Rate</span> : ''}</label>
              <input
                type="number"
                className="form-input"
                placeholder={orderType === 'Market' ? 'Auto' : 'Enter price'}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                disabled={orderType === 'Market' || orderType === 'Stop Loss Market'}
              />
            </div>
          </div>

          {isSLOrder && (
            <div className="field-group">
              <label className="field-label">Trigger Price (₹)</label>
              <input
                type="number"
                className="form-input"
                placeholder="Stop loss trigger price"
                value={triggerPrice}
                onChange={(e) => setTriggerPrice(e.target.value)}
              />
            </div>
          )}

          <div className="field-group">
            <label className="field-label">Validity</label>
            <div className="select-wrapper">
              <select className="form-select">
                <option>Day</option>
                <option>IOC (Immediate or Cancel)</option>
              </select>
              <ChevronDown size={16} className="select-icon" />
            </div>
          </div>

          {orderError && (
            <div className="error-banner">
              <AlertCircle size={16} /> {orderError}
            </div>
          )}

          <button
            className={`search-btn order-submit-btn ${orderSide === 'SELL' ? 'sell-btn' : 'buy-btn'}`}
            onClick={handlePlaceOrder}
          >
            {orderSide === 'BUY' ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            Place {orderSide} Order
          </button>

          <AnimatePresence>
            {orderPlaced && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="success-banner"
              >
                <CheckCircle size={18} />
                {orderSide} order for <strong>{qty} × {symbol || 'N/A'}</strong> placed successfully!
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Order Summary Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-card">
            <h3 className="section-label">Order Summary</h3>
            <div className="status-row">
              <span className="text-muted">Symbol</span>
              <span className="fw-700">{symbol || '—'}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Exchange</span>
              <span>{exchange}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Type</span>
              <span>{orderType}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Product</span>
              <span>{product}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Quantity</span>
              <span className="fw-700">{qty || '—'}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Price</span>
              <span className="fw-700">{price ? `₹${price}` : orderType === 'Market' ? 'At Market' : '—'}</span>
            </div>
            <div className="status-row">
              <span className="text-muted">Side</span>
              <span className={orderSide === 'BUY' ? 'badge-green' : 'badge-red'}>{orderSide}</span>
            </div>
          </div>

          
        </div>
      </div>
    </motion.div>
  );
}
