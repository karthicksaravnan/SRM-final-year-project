import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ListOrdered, RefreshCw, AlertCircle, Search, BookOpen, Receipt, History } from 'lucide-react';
import * as api from '../lib/api';

const TABS = [
  { key: 'orders', label: 'Order Book', icon: BookOpen },
  { key: 'trades', label: 'Trade Book', icon: Receipt },
  { key: 'history', label: 'Order History', icon: History },
];

const sideClass = (t) => (t === 'B' ? 'badge-green' : t === 'S' ? 'badge-red' : '');
const sideLabel = (t) => (t === 'B' ? 'BUY' : t === 'S' ? 'SELL' : t || '—');

function StatusBadge({ status }) {
  const s = (status || '').toLowerCase();
  let cls = 'badge-amber';
  if (s.includes('complete') || s.includes('traded') || s.includes('filled')) cls = 'badge-green';
  else if (s.includes('reject') || s.includes('cancel')) cls = 'badge-red';
  return <span className={cls}>{status || '—'}</span>;
}

export default function Orders({ user }) {
  const [tab, setTab] = useState('orders');
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [historyOrderNo, setHistoryOrderNo] = useState('');

  const loadOrders = async () => {
    setLoading(true); setError('');
    try {
      const res = await api.getOrders(user.id);
      setRows(res.data || []);
    } catch (e) { setError(e.message); setRows([]); }
    finally { setLoading(false); }
  };

  const loadTrades = async () => {
    setLoading(true); setError('');
    try {
      const res = await api.getTrades(user.id);
      setRows(res.data || []);
    } catch (e) { setError(e.message); setRows([]); }
    finally { setLoading(false); }
  };

  const loadHistory = async () => {
    if (!historyOrderNo) { setError('Enter an order number to fetch its history.'); return; }
    setLoading(true); setError('');
    try {
      const res = await api.getOrderHistory(user.id, historyOrderNo.trim());
      setRows(res.data || []);
    } catch (e) { setError(e.message); setRows([]); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    setRows([]); setError('');
    if (tab === 'orders') loadOrders();
    else if (tab === 'trades') loadTrades();
    // history is on-demand (needs an order number)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const refresh = () => {
    if (tab === 'orders') loadOrders();
    else if (tab === 'trades') loadTrades();
    else loadHistory();
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="page-wrapper">
      <div className="page-title-row">
        <div className="page-icon-wrap order-icon"><ListOrdered size={28} /></div>
        <div>
          <h1 className="page-title">Orders &amp; Trades</h1>
          <p className="text-muted">Live order book, trade book and order history from Kotak Neo</p>
        </div>
        <button className="search-btn add-btn" onClick={refresh} disabled={loading}>
          <RefreshCw size={16} className={loading ? 'spin' : ''} /> Refresh
        </button>
      </div>

      {/* Tabs */}
      <div className="tab-bar">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.key} className={`tab-btn ${tab === t.key ? 'active' : ''}`} onClick={() => setTab(t.key)}>
              <Icon size={16} /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === 'history' && (
        <div className="glass-card" style={{ marginBottom: '1.25rem', padding: '1.25rem' }}>
          <div className="glass-input-box" style={{ margin: 0 }}>
            <input placeholder="Enter Nest Order No (nOrdNo), e.g. 250720000007242"
              value={historyOrderNo} onChange={(e) => setHistoryOrderNo(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && loadHistory()} />
            <button className="search-btn" onClick={loadHistory} disabled={loading}>
              <Search size={16} /> Fetch History
            </button>
          </div>
        </div>
      )}

      {error && <div className="error-banner" style={{ marginBottom: '1rem' }}><AlertCircle size={16} /> {error}</div>}

      <div className="glass-card" style={{ padding: '1.5rem', overflow: 'auto' }}>
        {loading ? (
          <div className="loading-container"><div className="spinner" /><p>Fetching {tab}...</p></div>
        ) : rows.length === 0 ? (
          <p className="text-muted" style={{ textAlign: 'center', padding: '2rem 0' }}>
            {tab === 'history' ? 'Enter an order number above to view its lifecycle.' : 'No records found for today.'}
          </p>
        ) : (
          <table className="holdings-table">
            <thead>
              {tab === 'orders' && (
                <tr><th>Order No</th><th>Symbol</th><th>Side</th><th>Type</th><th>Qty</th><th>Price</th><th>Avg</th><th>Validity</th><th>Status</th></tr>
              )}
              {tab === 'trades' && (
                <tr><th>Order No</th><th>Symbol</th><th>Side</th><th>Type</th><th>Qty</th><th>Filled</th><th>Avg Price</th><th>Product</th><th>Trade Time</th></tr>
              )}
              {tab === 'history' && (
                <tr><th>Order No</th><th>Time</th><th>Status</th><th>Side</th><th>Type</th><th>Qty</th><th>Price</th><th>Avg</th><th>Reject Reason</th></tr>
              )}
            </thead>
            <tbody>
              {tab === 'orders' && rows.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.nOrdNo}</td>
                  <td><span className="ticker-capsule" style={{ fontSize: '0.72rem' }}>{r.trdSym}</span></td>
                  <td><span className={sideClass(r.trnsTp)}>{sideLabel(r.trnsTp)}</span></td>
                  <td>{r.prcTp}</td>
                  <td>{r.qty}</td>
                  <td>₹{r.prc}</td>
                  <td>₹{r.avgPrc}</td>
                  <td>{r.vldt}</td>
                  <td><StatusBadge status={r.ordSt} /></td>
                </tr>
              ))}
              {tab === 'trades' && rows.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.nOrdNo}</td>
                  <td><span className="ticker-capsule" style={{ fontSize: '0.72rem' }}>{r.trdSym}</span></td>
                  <td><span className={sideClass(r.trnsTp)}>{sideLabel(r.trnsTp)}</span></td>
                  <td>{r.prcTp}</td>
                  <td>{r.qty}</td>
                  <td>{r.fldQty}</td>
                  <td className="fw-700">₹{r.avgPrc}</td>
                  <td>{r.prod}</td>
                  <td className="text-muted" style={{ fontSize: '0.8rem' }}>{r.exTm || r.flDt}</td>
                </tr>
              ))}
              {tab === 'history' && rows.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.nOrdNo}</td>
                  <td className="text-muted" style={{ fontSize: '0.8rem' }}>{r.flDtTm}</td>
                  <td><StatusBadge status={r.ordSt} /></td>
                  <td><span className={sideClass(r.trnsTp)}>{sideLabel(r.trnsTp)}</span></td>
                  <td>{r.prcTp}</td>
                  <td>{r.qty}</td>
                  <td>₹{r.prc}</td>
                  <td>₹{r.avgPrc}</td>
                  <td className="text-red" style={{ fontSize: '0.8rem' }}>{r.rejRsn || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </motion.div>
  );
}
