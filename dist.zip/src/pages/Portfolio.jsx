import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { PieChart, RefreshCw, TrendingUp, TrendingDown, BarChart3, AlertCircle } from 'lucide-react';
import * as api from '../lib/api';

const num = (v) => (typeof v === 'number' ? v : parseFloat(v) || 0);
const inr = (v) => '₹' + num(v).toLocaleString('en-IN', { maximumFractionDigits: 2 });

export default function Portfolio({ user }) {
  const [holdings, setHoldings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true); setError('');
    try {
      const res = await api.getHoldings(user.id);
      setHoldings(res.data || []);
    } catch (e) { setError(e.message); setHoldings([]); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const totalInvested = holdings.reduce((s, h) => s + num(h.holdingCost || num(h.averagePrice) * num(h.quantity)), 0);
  const totalCurrent = holdings.reduce((s, h) => s + num(h.mktValue || num(h.closingPrice) * num(h.quantity)), 0);
  const totalPnl = totalCurrent - totalInvested;
  const totalPnlPct = totalInvested ? ((totalPnl / totalInvested) * 100).toFixed(2) : '0.00';

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="page-wrapper">
      <div className="page-title-row">
        <div className="page-icon-wrap portfolio-icon"><PieChart size={28} /></div>
        <div>
          <h1 className="page-title">Holdings</h1>
          <p className="text-muted">Your live equity portfolio from Kotak Neo</p>
        </div>
        <button className="search-btn add-btn" onClick={load} disabled={loading}>
          <RefreshCw size={16} className={loading ? 'spin' : ''} /> Refresh
        </button>
      </div>

      <div className="portfolio-summary">
        <div className="glass-card summary-card">
          <span className="summary-label">Total Invested</span>
          <span className="summary-value">{inr(totalInvested)}</span>
        </div>
        <div className="glass-card summary-card">
          <span className="summary-label">Current Value</span>
          <span className="summary-value text-green">{inr(totalCurrent)}</span>
        </div>
        <div className="glass-card summary-card">
          <span className="summary-label">Total P&amp;L</span>
          <span className={`summary-value ${totalPnl >= 0 ? 'text-green' : 'text-red'}`}>
            {totalPnl >= 0 ? '+' : ''}{inr(totalPnl)}
          </span>
        </div>
        <div className="glass-card summary-card">
          <span className="summary-label">Overall Return</span>
          <span className={`summary-value ${totalPnl >= 0 ? 'text-green' : 'text-red'}`}>
            {totalPnl >= 0 ? '▲' : '▼'} {Math.abs(totalPnlPct)}%
          </span>
        </div>
      </div>

      {error && <div className="error-banner" style={{ marginBottom: '1rem' }}><AlertCircle size={16} /> {error}</div>}

      <div className="glass-card" style={{ padding: '1.5rem', overflow: 'auto' }}>
        <h3 className="section-label"><BarChart3 size={18} /> My Holdings</h3>
        {loading ? (
          <div className="loading-container"><div className="spinner" /><p>Fetching holdings...</p></div>
        ) : holdings.length === 0 ? (
          <p className="text-muted" style={{ textAlign: 'center', padding: '2rem 0' }}>
            No holdings found. Connect your broker on the Broker page to view your portfolio.
          </p>
        ) : (
          <table className="holdings-table">
            <thead>
              <tr>
                <th>Symbol</th><th>Name</th><th>Qty</th><th>Avg Price</th><th>LTP</th>
                <th>Curr. Value</th><th>P&amp;L</th><th>Return %</th>
              </tr>
            </thead>
            <tbody>
              {holdings.map((h, i) => {
                const qty = num(h.quantity);
                const avg = num(h.averagePrice);
                const ltp = num(h.closingPrice);
                const cur = num(h.mktValue || ltp * qty);
                const invested = num(h.holdingCost || avg * qty);
                const pnl = num(h.unrealisedGainLoss ?? (cur - invested));
                const pct = invested ? (pnl / invested) * 100 : 0;
                return (
                  <tr key={i}>
                    <td><span className="ticker-capsule" style={{ fontSize: '0.75rem' }}>{h.displaySymbol || h.symbol}</span></td>
                    <td className="text-muted" style={{ fontSize: '0.85rem' }}>{h.instrumentName}</td>
                    <td>{qty}</td>
                    <td>{inr(avg)}</td>
                    <td>{inr(ltp)}</td>
                    <td>{inr(cur)}</td>
                    <td className={pnl >= 0 ? 'text-green fw-700' : 'text-red fw-700'}>
                      {pnl >= 0 ? '+' : ''}{inr(pnl)}
                    </td>
                    <td>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px' }} className={pct >= 0 ? 'text-green' : 'text-red'}>
                        {pct >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                        {Math.abs(pct).toFixed(2)}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </motion.div>
  );
}
