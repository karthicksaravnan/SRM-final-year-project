import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, TrendingUp, TrendingDown, Activity, Zap, BarChart3, ShieldCheck, AlertCircle, Award, Target, Layout, LogOut, Briefcase, PieChart, Info, BookOpen, ShoppingCart, User, UserPlus, Home, ListOrdered, ChevronDown } from 'lucide-react';
import Broker from './pages/Broker';
import Portfolio from './pages/Portfolio';
import Research from './pages/Research';
import PlaceOrder from './pages/PlaceOrder';
import Orders from './pages/Orders';
import * as api from './lib/api';

const POPULAR_STOCKS = [
  { symbol: 'RELIANCE', name: 'Reliance Industries', sector: 'Energy' },
  { symbol: 'TCS', name: 'Tata Consultancy Services', sector: 'IT' },
  { symbol: 'INFY', name: 'Infosys', sector: 'IT' },
  { symbol: 'HDFCBANK', name: 'HDFC Bank', sector: 'Banking' },
  { symbol: 'ICICIBANK', name: 'ICICI Bank', sector: 'Banking' },
  { symbol: 'SBIN', name: 'State Bank of India', sector: 'Banking' },
  { symbol: 'BHARTIARTL', name: 'Bharti Airtel', sector: 'Telecom' },
  { symbol: 'ITC', name: 'ITC Ltd', sector: 'FMCG' },
  { symbol: 'HINDUNILVR', name: 'Hindustan Unilever', sector: 'FMCG' },
  { symbol: 'LT', name: 'Larsen & Toubro', sector: 'Infra' },
  { symbol: 'KOTAKBANK', name: 'Kotak Mahindra Bank', sector: 'Banking' },
  { symbol: 'AXISBANK', name: 'Axis Bank', sector: 'Banking' },
  { symbol: 'BAJFINANCE', name: 'Bajaj Finance', sector: 'NBFC' },
  { symbol: 'WIPRO', name: 'Wipro', sector: 'IT' },
  { symbol: 'MARUTI', name: 'Maruti Suzuki', sector: 'Auto' },
  { symbol: 'TATAMOTORS', name: 'Tata Motors', sector: 'Auto' },
  { symbol: 'SUNPHARMA', name: 'Sun Pharmaceutical', sector: 'Pharma' },
  { symbol: 'ASIANPAINT', name: 'Asian Paints', sector: 'Materials' },
  { symbol: 'TITAN', name: 'Titan Company', sector: 'Consumer' },
  { symbol: 'TATASTEEL', name: 'Tata Steel', sector: 'Materials' },
];

const Login = ({ setView, onAuth }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError('');
    if (!email || !password) return setError('Email and password are required.');
    setLoading(true);
    try {
      const user = await api.login(email, password);
      api.setUser(user);
      onAuth(user);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="static-page auth-page">
      <div className="glass-card form-card">
        <h2><User size={24} /> Access Account</h2>
        <p className="text-muted">Enter your credentials to continue</p>
        <input type="email" placeholder="Email" className="form-input" value={email}
          onChange={(e) => setEmail(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleLogin()} />
        <input type="password" placeholder="Password" className="form-input" value={password}
          onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleLogin()} />
        {error && <div className="error-banner"><AlertCircle size={16} /> {error}</div>}
        <button className="search-btn full-width" onClick={handleLogin} disabled={loading}>
          {loading ? 'Signing in...' : 'Login to System'}
        </button>
        <p className="text-muted text-center mt-4">New here? <span className="text-primary cursor-pointer" onClick={() => setView('signup')}>Create an account</span></p>
      </div>
    </motion.div>
  );
};

const Signup = ({ setView, onAuth }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    setError('');
    if (!name || !email || !password) return setError('All fields are required.');
    setLoading(true);
    try {
      const user = await api.signup(name, email, password);
      api.setUser(user);
      onAuth(user);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="static-page auth-page">
      <div className="glass-card form-card">
        <h2><UserPlus size={24} /> Initialize Profile</h2>
        <p className="text-muted">Join the intelligent investing network</p>
        <input type="text" placeholder="Full Name" className="form-input" value={name} onChange={(e) => setName(e.target.value)} />
        <input type="email" placeholder="Email Address" className="form-input" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Secure Password" className="form-input" value={password}
          onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSignup()} />
        {error && <div className="error-banner"><AlertCircle size={16} /> {error}</div>}
        <button className="search-btn full-width" onClick={handleSignup} disabled={loading}>
          {loading ? 'Creating...' : 'Register Profile'}
        </button>
        <p className="text-muted text-center mt-4">Already initialized? <span className="text-primary cursor-pointer" onClick={() => setView('login')}>Sign In</span></p>
      </div>
    </motion.div>
  );
};

function App() {
  const existing = api.getUser();
  const [user, setUser] = useState(existing);
  const [currentView, setCurrentView] = useState(existing ? 'dashboard' : 'login');
  const [symbol, setSymbol] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showSuggest, setShowSuggest] = useState(false);

  const handleAuth = (u) => {
    setUser(u);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    api.logout();
    setUser(null);
    setCurrentView('login');
  };

  const handleSearch = async (term) => {
    const query = (term ?? symbol).trim();
    if (!query) return;
    setShowSuggest(false);
    setLoading(true);
    setError('');
    setData(null);
    try {
      const result = await api.analyze(query);
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const pickStock = (s) => {
    setSymbol(s.symbol);
    handleSearch(s.symbol);
  };

  const filteredStocks = symbol
    ? POPULAR_STOCKS.filter(
        (s) =>
          s.symbol.includes(symbol.toUpperCase()) ||
          s.name.toLowerCase().includes(symbol.toLowerCase())
      )
    : POPULAR_STOCKS;

  const formatCurrency = (val) => {
    if (val == null) return 'N/A';
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: data?.currency || 'INR',
      notation: 'compact'
    }).format(val);
  };

  const formatPercent = (val) => {
    if (val == null) return 'N/A';
    return (val * 100).toFixed(2) + '%';
  };

  const renderView = () => {
    switch (currentView) {
      case 'login': return <Login setView={setCurrentView} onAuth={handleAuth} />;
      case 'signup': return <Signup setView={setCurrentView} onAuth={handleAuth} />;
      case 'broker': return <Broker user={user} />;
      case 'portfolio': return <Portfolio user={user} />;
      case 'orders': return <Orders user={user} />;
      case 'about': return <StaticPage title="About StockInsight AI" icon={Info} desc="System documentation and version history." />;
      case 'research': return <Research />;
      case 'order': return <PlaceOrder user={user} />;
      case 'dashboard':
      default:
        return (
          <>
            <motion.header initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
              <h1>StockInsight <span className="ai-pill">AI</span></h1>
              <p>Quantum-Grade Fundamental Intelligence</p>
            </motion.header>

            <div className="search-section">
              <div className="glass-input-box">
                <input
                  type="text"
                  placeholder="Search Global Markets (e.g. RELIANCE, TCS)"
                  value={symbol}
                  onChange={(e) => { setSymbol(e.target.value.toUpperCase()); setShowSuggest(true); }}
                  onFocus={() => setShowSuggest(true)}
                  onBlur={() => setTimeout(() => setShowSuggest(false), 150)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <button
                  className="dropdown-toggle"
                  onClick={() => setShowSuggest((v) => !v)}
                  title="Browse popular stocks"
                >
                  <ChevronDown size={18} className={`chev ${showSuggest ? 'open' : ''}`} />
                </button>
                <button className="search-btn" onClick={() => handleSearch()} disabled={loading}>
                  {loading ? 'Analyzing...' : 'Execute Analysis'}
                </button>
              </div>

              {showSuggest && (
                <motion.div
                  className="suggest-panel"
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.18 }}
                >
                  <div className="suggest-head">{symbol ? 'Matches' : 'Popular Stocks'}</div>
                  {filteredStocks.length === 0 ? (
                    <div className="suggest-empty">No matches — press Enter to search “{symbol}”.</div>
                  ) : (
                    filteredStocks.map((s) => (
                      <div key={s.symbol} className="suggest-item" onMouseDown={() => pickStock(s)}>
                        <div>
                          <span className="suggest-sym">{s.symbol}</span>
                          <div className="suggest-name">{s.name}</div>
                        </div>
                        <span className="suggest-tag">{s.sector}</span>
                      </div>
                    ))
                  )}
                </motion.div>
              )}
            </div>

            <AnimatePresence>
              {loading && (
                <motion.div className="loading-container" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                  <div className="spinner"></div>
                  <p>Scanning Financial Vectors...</p>
                </motion.div>
              )}

              {error && (
                <motion.div className="error-msg" initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                  <AlertCircle size={20} />
                  <span>{error}</span>
                </motion.div>
              )}

              {data && (
                <motion.div className="dashboard-layout" initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
                  <div className="glass-card hero-insight">
                    <div className="radar-content">
                      <div className="radar-ring">
                        <motion.div className="radar-fill" initial={{ rotate: -90 }} animate={{ rotate: (data.fundamental_score * 36) - 90 }} transition={{ duration: 1, ease: "easeOut" }} />
                        <div className="radar-score-box">
                          <span className="radar-score">{data.fundamental_score}</span>
                          <span className="radar-desc">Health Score</span>
                        </div>
                      </div>
                      <div className="verdict-info">
                        <p className="text-muted">Investment Recommendation</p>
                        <h2 className={`recommendation-label rec-${data.recommendation.split(' ')[0].toLowerCase()}`}>
                          {data.recommendation}
                        </h2>
                        <div className="sector-badges">
                          <span className="ticker-capsule">{data.symbol.split('.')[0]}</span>
                          <span className="sector-capsule">{data.sector}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card returns-aside">
                    <h3><TrendingUp size={18} /> Market Momentum</h3>
                    <div className="peer-list">
                      <div className="return-item">
                        <span className="label">1 Year Return</span>
                        <div className={`return-pill ${data.one_year_return > 0 ? 'text-green' : 'text-red'}`}>
                          {data.one_year_return > 0 ? <TrendingUp size={14}/> : <TrendingDown size={14}/>}
                          {formatPercent(data.one_year_return)}
                        </div>
                      </div>
                      <div className="return-item">
                        <span className="label">5 Year Return</span>
                        <div className={`return-pill ${data.five_year_return > 0 ? 'text-green' : 'text-red'}`}>
                          {data.five_year_return > 0 ? <TrendingUp size={14}/> : <TrendingDown size={14}/>}
                          {formatPercent(data.five_year_return)}
                        </div>
                      </div>
                      <div className="return-item">
                        <span className="label">Analyst Pulse</span>
                        <div className="return-pill text-green">
                          <Target size={14} /> {data.analyst_rating || 'Strong Buy'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card swot-card">
                    <div className="swot-grid">
                      <div className="swot-box">
                        <h5 className="text-green">Strengths</h5>
                        <ul>
                          {data.strengths.map((s, i) => <li key={i}>✓ {s}</li>)}
                        </ul>
                      </div>
                      <div className="swot-box">
                        <h5 className="text-red">Weaknesses</h5>
                        <ul>
                          {data.weaknesses.length > 0 ? data.weaknesses.map((w, i) => <li key={i}>△ {w}</li>) : <li>No major alerts</li>}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="glass-card peer-card">
                    <h3><Award size={18} /> Sector Peers</h3>
                    <div className="peer-list">
                      {data.peers.map((p, i) => (
                        <div key={i} className="peer-item">
                          <div>
                            <strong>{p.symbol}</strong>
                            <p className="text-muted" style={{fontSize: '0.7rem'}}>{p.name}</p>
                          </div>
                          <span className="text-green">₹{p.price}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="metrics-row">
                    <div className="metric-pill">
                      <span className="label">Intrinsic Fair Value</span>
                      <span className="value fair-value text-green">{formatCurrency(data.intrinsic_value)}</span>
                    </div>
                    <div className="metric-pill">
                      <span className="label">ROE %</span>
                      <span className="value">{formatPercent(data.roe)}</span>
                    </div>
                    <div className="metric-pill">
                      <span className="label">Debt/Equity</span>
                      <span className="value">{data.debt_to_equity?.toFixed(2)}</span>
                    </div>
                    <div className="metric-pill">
                      <span className="label">P/E Ratio</span>
                      <span className="value">{data.pe_ratio?.toFixed(2)}</span>
                    </div>
                    <div className="metric-pill">
                      <span className="label">Revenue (TTM)</span>
                      <span className="value">{formatCurrency(data.revenue)}</span>
                    </div>
                  </div>

                  <div className="glass-card methodology-card enhanced-methodology">
                    <div className="methodology-header">
                      <h3><ShieldCheck size={22} className="text-primary" /> Deep-Analysis Methodology</h3>
                      <div className="health-score-badge">
                        Health Score: <span className="score-value">{data.fundamental_score}/10</span>
                      </div>
                    </div>
                    <div className="methodology-body">
                      <p className="text-muted leading-relaxed">
                        The <strong>Health Score ({data.fundamental_score}/10)</strong> is a multi-variant vector calculated across 5 core pillars of fundamental analysis. It dynamically weights valuation multiples, capital efficiency, and solvency metrics against sector-specific baselines to derive a comprehensive investment grade.
                      </p>
                      <div className="method-grid-modern">
                        <div className="method-item-modern"><div className="method-icon-wrap"><BarChart3 size={16}/></div><div className="method-text"><strong>Valuation</strong><br/><span>P/E & DCF</span></div></div>
                        <div className="method-item-modern"><div className="method-icon-wrap"><Zap size={16}/></div><div className="method-text"><strong>Efficiency</strong><br/><span>ROE</span></div></div>
                        <div className="method-item-modern"><div className="method-icon-wrap"><ShieldCheck size={16}/></div><div className="method-text"><strong>Solvency</strong><br/><span>Debt/Equity</span></div></div>
                        <div className="method-item-modern"><div className="method-icon-wrap"><TrendingUp size={16}/></div><div className="method-text"><strong>Growth</strong><br/><span>Revenue %</span></div></div>
                        <div className="method-item-modern"><div className="method-icon-wrap"><Activity size={16}/></div><div className="method-text"><strong>Liquidity</strong><br/><span>FCF</span></div></div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        );
    }
  };

  const isAuthView = currentView === 'login' || currentView === 'signup';

  return (
    <div className={`app-layout ${isAuthView ? 'auth-layout' : 'main-layout'}`}>
      <div className="mesh-gradient"></div>

      {!isAuthView && (
        <aside className="sidebar">
          <div className="sidebar-brand" onClick={() => setCurrentView('dashboard')}>
            <Layout size={24} className="text-primary" />
            <span>StockInsight</span>
          </div>

          <nav className="sidebar-nav">
            <button className={`nav-item ${currentView === 'dashboard' ? 'active' : ''}`} onClick={() => setCurrentView('dashboard')}>
              <Home size={18} /> Dashboard
            </button>
            <button className={`nav-item ${currentView === 'broker' ? 'active' : ''}`} onClick={() => setCurrentView('broker')}>
              <Briefcase size={18} /> Broker
            </button>
            <button className={`nav-item ${currentView === 'orders' ? 'active' : ''}`} onClick={() => setCurrentView('orders')}>
              <ListOrdered size={18} /> Orders & Trades
            </button>
            <button className={`nav-item ${currentView === 'portfolio' ? 'active' : ''}`} onClick={() => setCurrentView('portfolio')}>
              <PieChart size={18} /> Holdings
            </button>
            <button className={`nav-item ${currentView === 'research' ? 'active' : ''}`} onClick={() => setCurrentView('research')}>
              <BookOpen size={18} /> Research
            </button>
            <button className={`nav-item ${currentView === 'order' ? 'active' : ''}`} onClick={() => setCurrentView('order')}>
              <ShoppingCart size={18} /> Place Order
            </button>
            <button className={`nav-item ${currentView === 'about' ? 'active' : ''}`} onClick={() => setCurrentView('about')}>
              <Info size={18} /> About App
            </button>
          </nav>

          <div className="sidebar-footer">
            {user && (
              <div className="sidebar-user">
                <div className="avatar-circle">{(user.name || 'U').charAt(0).toUpperCase()}</div>
                <div className="user-meta">
                  <span className="user-name">{user.name}</span>
                  <span className="user-email">{user.email}</span>
                </div>
              </div>
            )}
            <button className="nav-item logout-btn" onClick={handleLogout}>
              <LogOut size={18} /> Log Out
            </button>
          </div>
        </aside>
      )}

      <main className="main-content">
        {renderView()}
      </main>
    </div>
  );
}

const StaticPage = ({ title, icon: Icon, desc }) => (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="static-page">
    <div className="glass-card page-header">
      <h2><Icon size={28} /> {title}</h2>
      <p className="text-muted">{desc}</p>
      <div className="placeholder-content">
        <p>This module is currently running in simulated static mode. Live data integration pending in v2.0.</p>
      </div>
    </div>
  </motion.div>
);

export default App;
