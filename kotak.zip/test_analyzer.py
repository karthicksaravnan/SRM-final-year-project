import sys
import time

sys.path.append(r"d:\srm final year project\stock-analysis-app\backend")
from analyzer import analyze_stock

start = time.time()
print("Starting analysis...")
try:
    res = analyze_stock("TCS.NS")
    if isinstance(res, dict) and "error" in res:
        print("Error:", res["error"])
    else:
        print("Success! Keys:", res.keys())
except Exception as e:
    print("Exception:", e)
print("Time taken:", time.time() - start)
