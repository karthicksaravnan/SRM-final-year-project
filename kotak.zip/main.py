from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

import kotak
import models
from analyzer import analyze_stock
from database import Base, engine, get_db
from schemas import (
    AnalysisResult,
    BrokerLoginRequest,
    BrokerValidateRequest,
    LoginRequest,
    OrderHistoryRequest,
    SignupRequest,
)

app = FastAPI(title="StockInsight AI API")

# Create tables on startup (users, broker_sessions) if they don't exist.
Base.metadata.create_all(bind=engine)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def read_root():
    return {"message": "StockInsight AI API is running. Go to /docs for documentation."}


# ----------------------------------------------------------------------------
# Auth (simple demo: plain-text passwords per project requirement)
# ----------------------------------------------------------------------------
@app.post("/auth/signup")
def signup(req: SignupRequest, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.email == req.email).first()
    if existing:
        raise HTTPException(status_code=409, detail="An account with this email already exists.")
    user = models.User(name=req.name, email=req.email, password=req.password)
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"id": user.id, "name": user.name, "email": user.email, "token": str(user.id)}


@app.post("/auth/login")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == req.email).first()
    if not user or user.password != req.password:
        raise HTTPException(status_code=401, detail="Invalid email or password.")
    return {"id": user.id, "name": user.name, "email": user.email, "token": str(user.id)}


# ----------------------------------------------------------------------------
# Broker (Kotak Neo) login + session
# ----------------------------------------------------------------------------
def _get_session(user_id: int, db: Session) -> models.BrokerSession:
    sess = (
        db.query(models.BrokerSession)
        .filter(models.BrokerSession.user_id == user_id)
        .order_by(models.BrokerSession.id.desc())
        .first()
    )
    if not sess:
        raise HTTPException(status_code=400, detail="No active broker session. Please connect your broker.")
    return sess


@app.post("/broker/login")
def broker_login(req: BrokerLoginRequest):
    """Step 1: validate mobile/ucc/totp, return the intermediate view token + sid."""
    try:
        result = kotak.login_totp(req.access_token, req.mobile_number, req.ucc, req.totp)
    except kotak.KotakError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    if not result.get("view_token") or not result.get("sid"):
        raise HTTPException(status_code=502, detail="Kotak did not return a view token.")
    return result


@app.post("/broker/validate")
def broker_validate(req: BrokerValidateRequest, db: Session = Depends(get_db)):
    """Step 2: validate MPIN, persist the trade session for the user."""
    try:
        result = kotak.validate_mpin(req.access_token, req.sid, req.view_token, req.mpin)
    except kotak.KotakError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)
    if not result.get("session_token") or not result.get("base_url"):
        raise HTTPException(status_code=502, detail="Kotak did not return a trade session.")

    sess = models.BrokerSession(
        user_id=req.user_id,
        ucc=result.get("ucc"),
        greeting_name=result.get("greeting_name"),
        base_url=result["base_url"],
        session_token=result["session_token"],
        session_sid=result["sid"],
        access_token=req.access_token,
    )
    db.add(sess)
    db.commit()
    return {
        "connected": True,
        "greeting_name": result.get("greeting_name"),
        "ucc": result.get("ucc"),
        "base_url": result["base_url"],
    }


@app.get("/broker/status")
def broker_status(user_id: int, db: Session = Depends(get_db)):
    sess = (
        db.query(models.BrokerSession)
        .filter(models.BrokerSession.user_id == user_id)
        .order_by(models.BrokerSession.id.desc())
        .first()
    )
    if not sess:
        return {"connected": False}
    return {
        "connected": True,
        "broker": sess.broker,
        "ucc": sess.ucc,
        "greeting_name": sess.greeting_name,
        "connected_at": sess.created_at,
    }


@app.delete("/broker/disconnect")
def broker_disconnect(user_id: int, db: Session = Depends(get_db)):
    db.query(models.BrokerSession).filter(models.BrokerSession.user_id == user_id).delete()
    db.commit()
    return {"connected": False}


# ----------------------------------------------------------------------------
# Order / Trade / Holdings proxies
# ----------------------------------------------------------------------------
def _proxy(user_id, db, fn, *args):
    sess = _get_session(user_id, db)
    try:
        return fn(sess.base_url, sess.session_token, sess.session_sid, *args)
    except kotak.KotakError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


@app.get("/broker/orders")
def get_orders(user_id: int, db: Session = Depends(get_db)):
    return {"data": _proxy(user_id, db, kotak.order_book)}


@app.get("/broker/trades")
def get_trades(user_id: int, db: Session = Depends(get_db)):
    return {"data": _proxy(user_id, db, kotak.trade_book)}


@app.post("/broker/order-history")
def get_order_history(req: OrderHistoryRequest, db: Session = Depends(get_db)):
    return {"data": _proxy(req.user_id, db, kotak.order_history, req.order_no)}


@app.get("/broker/holdings")
def get_holdings(user_id: int, db: Session = Depends(get_db)):
    return {"data": _proxy(user_id, db, kotak.holdings)}


# ----------------------------------------------------------------------------
# Stock fundamental analysis (existing)
# ----------------------------------------------------------------------------
@app.get("/analyze/{symbol}", response_model=AnalysisResult)
def analyze(symbol: str):
    result = analyze_stock(symbol.upper())
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
