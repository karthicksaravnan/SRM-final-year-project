from datetime import datetime

from sqlalchemy import Column, DateTime, Integer, String, Text

from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    email = Column(String(190), unique=True, index=True, nullable=False)
    # Demo app: password stored as plain text per project requirement.
    password = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class BrokerSession(Base):
    """Stores the active Kotak Neo trade session for a user."""

    __tablename__ = "broker_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    broker = Column(String(50), default="Kotak Neo")
    ucc = Column(String(50))
    greeting_name = Column(String(120))
    base_url = Column(String(255), nullable=False)
    session_token = Column(Text, nullable=False)
    session_sid = Column(String(120), nullable=False)
    access_token = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
