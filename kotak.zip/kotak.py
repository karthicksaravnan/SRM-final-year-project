"""Thin client for the Kotak Securities Neo Trade API.

The browser cannot call Kotak directly (CORS + secret tokens), so the FastAPI
backend acts as a proxy. Login is a two-step flow:
  1. tradeApiLogin  -> view token + sid   (validated with mobile/ucc/totp)
  2. tradeApiValidate -> trade session token + sid + baseUrl (validated with mpin)
All post-login APIs use baseUrl + the trade session token/sid.
"""

import json

import requests

LOGIN_BASE = "https://mis.kotaksecurities.com/login/1.0"
NEO_FIN_KEY = "neotradeapi"
TIMEOUT = 20


class KotakError(Exception):
    def __init__(self, message, status_code=502):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _data_or_raise(resp):
    try:
        payload = resp.json()
    except ValueError:
        raise KotakError(f"Kotak returned a non-JSON response (HTTP {resp.status_code}).")

    # Login-style responses nest everything under "data"; some error responses are flat.
    if isinstance(payload, dict):
        if payload.get("status") == "error" or payload.get("stat") == "Not_Ok":
            msg = payload.get("message") or payload.get("emsg") or "Kotak request failed."
            code = payload.get("errorCode") or payload.get("stCode") or resp.status_code
            raise KotakError(str(msg), 400 if str(code).startswith("4") else 502)
    if not resp.ok:
        raise KotakError(f"Kotak request failed (HTTP {resp.status_code}).", resp.status_code)
    return payload


def login_totp(access_token, mobile_number, ucc, totp):
    """Step 1: validate credentials + TOTP, returns the view token + sid."""
    headers = {
        "Authorization": access_token,
        "neo-fin-key": NEO_FIN_KEY,
        "Content-Type": "application/json",
    }
    body = {"mobileNumber": mobile_number, "ucc": ucc, "totp": totp}
    resp = requests.post(
        f"{LOGIN_BASE}/tradeApiLogin", headers=headers, json=body, timeout=TIMEOUT
    )
    data = _data_or_raise(resp).get("data", {})
    return {
        "view_token": data.get("token"),
        "sid": data.get("sid"),
        "greeting_name": data.get("greetingName"),
    }


def validate_mpin(access_token, view_sid, view_token, mpin):
    """Step 2: validate MPIN, returns the trade session token + sid + baseUrl."""
    headers = {
        "Authorization": access_token,
        "neo-fin-key": NEO_FIN_KEY,
        "sid": view_sid,
        "Auth": view_token,
        "Content-Type": "application/json",
    }
    resp = requests.post(
        f"{LOGIN_BASE}/tradeApiValidate",
        headers=headers,
        json={"mpin": mpin},
        timeout=TIMEOUT,
    )
    data = _data_or_raise(resp).get("data", {})
    return {
        "session_token": data.get("token"),
        "sid": data.get("sid"),
        "base_url": data.get("baseUrl"),
        "greeting_name": data.get("greetingName"),
        "ucc": data.get("ucc"),
    }


def _session_headers(session_token, session_sid):
    return {
        "accept": "application/json",
        "Auth": session_token,
        "Sid": session_sid,
        "neo-fin-key": NEO_FIN_KEY,
    }


def order_book(base_url, session_token, session_sid):
    resp = requests.get(
        f"{base_url}/quick/user/orders",
        headers=_session_headers(session_token, session_sid),
        timeout=TIMEOUT,
    )
    return _data_or_raise(resp).get("data", [])


def trade_book(base_url, session_token, session_sid):
    resp = requests.get(
        f"{base_url}/quick/user/trades",
        headers=_session_headers(session_token, session_sid),
        timeout=TIMEOUT,
    )
    return _data_or_raise(resp).get("data", [])


def order_history(base_url, session_token, session_sid, order_no):
    headers = _session_headers(session_token, session_sid)
    headers["Content-Type"] = "application/x-www-form-urlencoded"
    resp = requests.post(
        f"{base_url}/quick/order/history",
        headers=headers,
        data={"jData": json.dumps({"nOrdNo": order_no})},
        timeout=TIMEOUT,
    )
    return _data_or_raise(resp).get("data", [])


def holdings(base_url, session_token, session_sid):
    resp = requests.get(
        f"{base_url}/portfolio/v1/holdings",
        headers=_session_headers(session_token, session_sid),
        timeout=TIMEOUT,
    )
    return _data_or_raise(resp).get("data", [])
