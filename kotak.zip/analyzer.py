import yfinance as yf
import pandas as pd
import numpy as np

def calculate_intrinsic_value(fcf, growth_rate=0.05, discount_rate=0.1, terminal_growth=0.02, years=5):
    """Simple DCF calculation"""
    if fcf is None or fcf <= 0:
        return None
    
    projected_fcf = []
    current_fcf = fcf
    for i in range(1, years + 1):
        current_fcf *= (1 + growth_rate)
        projected_fcf.append(current_fcf / ((1 + discount_rate) ** i))
    
    terminal_value = (current_fcf * (1 + terminal_growth)) / (discount_rate - terminal_growth)
    discounted_terminal_value = terminal_value / ((1 + discount_rate) ** years)
    
    return sum(projected_fcf) + discounted_terminal_value

def analyze_stock(symbol: str):
    # Automatically handle Indian stocks (NSE) if no suffix is provided
    if "." not in symbol:
        symbol = f"{symbol}.NS"
    
    ticker = yf.Ticker(symbol)
    
    try:
        info = ticker.info
        if not info or 'regularMarketPrice' not in info and 'currentPrice' not in info:
             # Try to see if it's a valid ticker at all
             if 'symbol' not in info:
                 return {"error": "Invalid stock symbol or no data available"}
    except Exception as e:
        return {"error": f"Error fetching data: {str(e)}"}

    # Get dataframes
    income_stmt = ticker.income_stmt
    balance_sheet = ticker.balance_sheet
    cash_flow = ticker.cashflow
    
    if income_stmt.empty or balance_sheet.empty or cash_flow.empty:
        return {"error": "Missing financial statements for this symbol"}

    # Extract values (using latest available year)
    try:
        current_price = info.get('currentPrice') or info.get('regularMarketPreviousClose')
        revenue = income_stmt.loc['Total Revenue'].iloc[0]
        prev_revenue = income_stmt.loc['Total Revenue'].iloc[1] if len(income_stmt.loc['Total Revenue']) > 1 else None
        net_income = income_stmt.loc['Net Income'].iloc[0]
        
        total_assets = balance_sheet.loc['Total Assets'].iloc[0]
        total_liabilities = balance_sheet.loc['Total Liabilities Net Minority Interest'].iloc[0] if 'Total Liabilities Net Minority Interest' in balance_sheet.index else balance_sheet.loc['Total Debt'].iloc[0] # Fallback
        
        # Shareholder Equity
        shareholder_equity = balance_sheet.loc['Stockholders Equity'].iloc[0] if 'Stockholders Equity' in balance_sheet.index else (total_assets - total_liabilities)
        
        total_debt = info.get('totalDebt') or (balance_sheet.loc['Total Debt'].iloc[0] if 'Total Debt' in balance_sheet.index else 0)
        
        fcf = cash_flow.loc['Free Cash Flow'].iloc[0] if 'Free Cash Flow' in cash_flow.index else None
        
        # Calculations
        eps = info.get('trailingEps')
        pe_ratio = info.get('trailingPE')
        if pe_ratio is None and eps and eps > 0:
            pe_ratio = current_price / eps
            
        roe = net_income / shareholder_equity if shareholder_equity != 0 else None
        debt_to_equity = total_debt / shareholder_equity if shareholder_equity != 0 else None
        rev_growth = (revenue - prev_revenue) / prev_revenue if prev_revenue else None
        
        intrinsic_value = calculate_intrinsic_value(fcf)
        shares_outstanding = info.get('sharesOutstanding')
        if intrinsic_value and shares_outstanding:
            intrinsic_value = intrinsic_value / shares_outstanding
        
        # Advanced Analysis: Strengths & Weaknesses
        strengths = []
        weaknesses = []
        
        score = 0
        if roe:
            if roe > 0.15: 
                score += 2
                strengths.append("High Return on Equity (ROE)")
            elif roe < 0.05:
                weaknesses.append("Low capital efficiency (ROE)")
        
        if debt_to_equity is not None:
            if debt_to_equity < 0.5:
                score += 2
                strengths.append("Low debt-to-equity ratio")
            elif debt_to_equity > 1.5:
                weaknesses.append("High debt burden")
        
        if rev_growth:
            if rev_growth > 0.10:
                score += 2
                strengths.append("Strong revenue growth")
            elif rev_growth < -0.05:
                weaknesses.append("Declining revenue trend")
        
        if pe_ratio:
            if pe_ratio < 20:
                score += 2
                strengths.append("Attractive P/E valuation")
            elif pe_ratio > 50:
                weaknesses.append("Stretched valuation (High P/E)")
        
        if fcf and fcf > 0:
            score += 2
            strengths.append("Positive Free Cash Flow generation")
        elif fcf and fcf < 0:
            weaknesses.append("Negative cash flow (High burn)")

        # Statically defined sector categories to avoid slow peer lookups
        NSE_CATEGORIES = {
            "Financial Services": ["HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS", "KOTAKBANK.NS", "AXISBANK.NS", "BAJFINANCE.NS", "HDFCLIFE.NS"],
            "Technology": ["TCS.NS", "INFY.NS", "HCLTECH.NS", "WIPRO.NS", "LTIM.NS", "TECHM.NS"],
            "Energy": ["RELIANCE.NS", "ONGC.NS", "BPCL.NS", "IOC.NS", "POWERGRID.NS", "NTPC.NS", "ADANIGREEN.NS", "TATAPOWER.NS"],
            "Consumer Defensive": ["HINDUNILVR.NS", "ITC.NS", "NESTLEIND.NS", "BRITANNIA.NS", "DMART.NS"],
            "Consumer Cyclical": ["TATAMOTORS.NS", "M&M.NS", "MARUTI.NS", "BAJAJ-AUTO.NS", "EICHERMOT.NS", "TITAN.NS"],
            "Healthcare": ["SUNPHARMA.NS", "DRREDDY.NS", "CIPLA.NS", "APOLLOHOSP.NS", "DIVISLAB.NS"],
            "Basic Materials": ["TATASTEEL.NS", "JSWSTEEL.NS", "HINDALCO.NS", "ULTRACEMCO.NS", "GRASIM.NS", "ASIANPAINT.NS"],
            "Communication Services": ["BHARTIARTL.NS", "IDEA.NS"]
        }
        
        sector = info.get('sector')
        industry = info.get('industry')
        peer_list = []
        
        # Determine which static pool to use based on sector
        target_pool = NSE_CATEGORIES.get(sector, ["RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "BHARTIARTL.NS"]) # Fallback
        
        # Filter pool for same sector AND industry for high relevance
        matching_peers = []
        import concurrent.futures
        
        def fetch_peer(p_sym):
            if p_sym == symbol: return None
            try:
                p_ticker = yf.Ticker(p_sym)
                p_info = p_ticker.info
                return {
                    "symbol": p_sym.replace('.NS', ''),
                    "name": p_info.get('shortName', p_sym),
                    "price": p_info.get('currentPrice') or p_info.get('regularMarketPrice', 0),
                    "relevance": 2 if p_info.get('industry') == industry else 1
                }
            except: pass
            return None
            
        pool_to_check = [p for p in target_pool if p != symbol][:5]
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(fetch_peer, sym) for sym in pool_to_check]
            for future in concurrent.futures.as_completed(futures):
                res = future.result()
                if res:
                    matching_peers.append(res)
                if len(matching_peers) >= 3: break

        # Sort by relevance and take top 3
        matching_peers.sort(key=lambda x: x['relevance'], reverse=True)
        peer_list = matching_peers[:3]

        # Historical Returns
        hist = ticker.history(period="5y")
        one_year_return = None
        five_year_return = None
        
        if len(hist) > 252: # Approx 1 year trading days
            one_year_ago = hist.iloc[-252]['Close']
            one_year_return = (current_price - one_year_ago) / one_year_ago
        
        if len(hist) > 1260: # Approx 5 year trading days
            five_year_ago = hist.iloc[0]['Close']
            five_year_return = (current_price - five_year_ago) / five_year_ago

        # Classification & Recommendation
        classification = "Strong" if score >= 7 else "Moderate" if score >= 4 else "Weak"
        
        if score >= 9: recommendation = "Strong Buy"
        elif score >= 7: recommendation = "Buy"
        elif score >= 5: recommendation = "Hold"
        elif score >= 3: recommendation = "Sell"
        else: recommendation = "Strong Sell"

        return {
            "symbol": symbol,
            "company_name": info.get('longName', symbol),
            "current_price": current_price,
            "pe_ratio": pe_ratio,
            "roe": roe,
            "debt_to_equity": debt_to_equity,
            "revenue_growth": rev_growth,
            "net_income": net_income,
            "revenue": revenue,
            "total_assets": total_assets,
            "total_liabilities": total_liabilities,
            "shareholder_equity": shareholder_equity,
            "free_cash_flow": fcf,
            "intrinsic_value": intrinsic_value,
            "fundamental_score": score,
            "classification": classification,
            "recommendation": recommendation,
            "strengths": strengths,
            "weaknesses": weaknesses,
            "sector": sector,
            "industry": info.get('industry'),
            "currency": info.get('currency', 'USD'),
            "one_year_return": one_year_return,
            "five_year_return": five_year_return,
            "analyst_rating": info.get('recommendationKey'),
            "target_price": info.get('targetMeanPrice'),
            "peers": peer_list
        }
    except Exception as e:
        return {"error": f"Error calculating metrics: {str(e)}"}
