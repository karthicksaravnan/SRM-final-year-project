from pydantic import BaseModel, EmailStr
from typing import Optional


class SignupRequest(BaseModel):
    name: str
    email: EmailStr
    password: str


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    name: str
    email: str


class BrokerLoginRequest(BaseModel):
    access_token: str
    mobile_number: str
    ucc: str
    totp: str


class BrokerValidateRequest(BaseModel):
    user_id: int
    access_token: str
    sid: str
    view_token: str
    mpin: str


class OrderHistoryRequest(BaseModel):
    user_id: int
    order_no: str


class AnalysisResult(BaseModel):
    symbol: str
    company_name: str
    current_price: float
    pe_ratio: Optional[float]
    roe: Optional[float]
    debt_to_equity: Optional[float]
    revenue_growth: Optional[float]
    net_income: Optional[float]
    revenue: Optional[float]
    total_assets: Optional[float]
    total_liabilities: Optional[float]
    shareholder_equity: Optional[float]
    free_cash_flow: Optional[float]
    intrinsic_value: Optional[float]
    fundamental_score: int
    classification: str
    recommendation: str
    strengths: list[str]
    weaknesses: list[str]
    sector: Optional[str]
    industry: Optional[str]
    currency: str
    
    # Advanced V2 Data
    one_year_return: Optional[float]
    five_year_return: Optional[float]
    analyst_rating: Optional[str]
    target_price: Optional[float]
    peers: list[dict] # [{symbol: "TCS", name: "Tata...", score: 8}]
